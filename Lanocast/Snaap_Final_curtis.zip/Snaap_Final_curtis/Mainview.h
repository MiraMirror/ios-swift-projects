//
//  Mainview.h
//  Snaap
//
//  Created by pratikjain on 27/01/15.
//  Copyright (c) 2015 pratik jain. All rights reserved.
//

//global
#import "Global.h"

#import <UIKit/UIKit.h>
#import <Social/Social.h>
#import <AVFoundation/AVFoundation.h>
#import <OpenEars/OEEventsObserver.h>
#import <RapidEars/OEPocketsphinxController+RapidEars.h>
#import <OpenEars/OEPocketsphinxController.h>

#import "SWRevealViewController.h"

#import "DACircularProgressView.h"
#import "DALabeledCircularProgressView.h"

#define GLOBAL [Global sharedInstance]

#define LAST_IMAGE @"lastimage"
#define SLIDER_VALUE @"slidervalue"
#define IS_SNAP_TAKEN_FIRST_TIME @"snaptakenfirsttime"




@class PocketsphinxController;

@interface Mainview : UIViewController <OEEventsObserverDelegate,SWRevealViewControllerDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,UIDocumentInteractionControllerDelegate>
{
    BOOL FrontCamera;
    BOOL haveImage;
    
    
    
    
    
    
   // VksCameraView *cameraView;

    OEEventsObserver *openEarsEventsObserver;
    
    // Strings which aren't required for OpenEars but which will help us show off the dynamic language features in this sample app.
    NSString *pathToFirstDynamicallyGeneratedLanguageModel;
    NSString *pathToFirstDynamicallyGeneratedDictionary;
    
    int restartAttemptsDueToPermissionRequests;
    BOOL startupFailedDueToLackOfPermissions;
    int SliderCountDown;
}
@property (strong, nonatomic) IBOutlet UILabel *take_pic_label;
@property (strong, nonatomic) IBOutlet UILabel *snap_label;

@property (strong, nonatomic) IBOutlet UILabel *show_anim;

@property (strong, nonatomic) IBOutlet UIImagePickerController *take_picker;
@property (strong, nonatomic) IBOutlet DALabeledCircularProgressView *labeledLargeProgressView;

@property (strong, nonatomic) NSTimer *secondsIndicatorTimer,*snapDelayTimer;
@property (nonatomic, assign) int restartAttemptsDueToPermissionRequests;
@property (nonatomic, assign) BOOL startupFailedDueToLackOfPermissions;
@property (nonatomic, strong) OEEventsObserver *openEarsEventsObserver;
- (IBAction)again_take_pic:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *star;


// Things which help us show off the dynamic language features.
@property (nonatomic, copy) NSString *pathToFirstDynamicallyGeneratedLanguageModel;
@property (nonatomic, copy) NSString *pathToFirstDynamicallyGeneratedDictionary;

@property (strong, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;

@property(nonatomic, strong)     UIDocumentInteractionController* docController;

@property (strong, nonatomic) IBOutlet UIImageView *captureImage;

//- (IBAction)star_camara:(id)sender;

- (IBAction) stopButtonAction;
- (IBAction) startButtonAction;
@property (strong, nonatomic) IBOutlet UIButton *btnRetake;
- (IBAction)Retake_click:(id)sender;

@end
