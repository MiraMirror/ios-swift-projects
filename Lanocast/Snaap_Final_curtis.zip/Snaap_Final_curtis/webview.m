//
//  webview.m
//  Snaap
//
//  Created by pratikjain on 01/04/15.
//  Copyright (c) 2015 pratik jain. All rights reserved.
//

#import "webview.h"

@interface webview ()
@property (strong, nonatomic) IBOutlet UIWebView *urlview;
@property(nonatomic, strong)UIActivityIndicatorView *activityIndicator;
@end

@implementation webview
{
    UIActivityIndicatorView *actInd;
    NSTimer *timer;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSURL *url=[NSURL URLWithString:@"http://lanocast.com/theone"];
    NSURLRequest *request= [NSURLRequest requestWithURL:url];
    [self.urlview loadRequest:request ];
    
    
    actInd=[[UIActivityIndicatorView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-25, self.view.frame.size.height/2-80, 50,50)];
    
    //Change the color of the indicator, this override the color set by UIActivityIndicatorViewStyleWhiteLarge
    actInd.color=[UIColor blackColor];
    
    [self.urlview loadRequest:request ];
    
    [self.urlview addSubview:actInd];
    
    timer =[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(webstart) userInfo:nil repeats:YES];
    
    
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)webstart
{
    if (!_urlview.loading) {
        
        [actInd stopAnimating];
    }
    else
    {
        [actInd startAnimating];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)Close_click:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
