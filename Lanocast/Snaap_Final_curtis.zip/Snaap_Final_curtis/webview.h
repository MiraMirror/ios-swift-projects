//
//  webview.h
//  Snaap
//
//  Created by pratikjain on 01/04/15.
//  Copyright (c) 2015 pratik jain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface webview : UIViewController
- (IBAction)Close_click:(id)sender;

@end
