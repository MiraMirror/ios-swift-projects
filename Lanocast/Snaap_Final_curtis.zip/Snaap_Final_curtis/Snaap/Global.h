//
//  Global.h
//  SpinNPress
//
//  Created by bviadmin on 11/11/14.
//  Copyright (c) 2014 BrainVire. All rights reserved.
//

#import <Foundation/Foundation.h>






#define PRODUCTION_SERVER "https://pguat.paytm.com/oltp-web/processTransaction?orderid="

//REDIRECTION_CONSTANTS
#define IS_ORDER_PLACED @"isorderplaced"
#define IS_FRESH_SIGNUP @"isFreshSignUP"
#define IS_PICKUP_ADDRESS_NOT_SET @"isPickupAddressNotSet"

#define _YES @"yes"
#define _NO @"no"

//Push notification constants
#define DEVICE_TOKEN @"devicetoken"
#define DEVICE_TOKEN_CTRLLR @"devicetokencontroller"
#define DEVICE_TOKEN_UPLOADED @"devicetokenuploaded"

//Estimation Summary Constants




//All webservices Reponse Tags
#define RESPONSE_DATA @"data"
#define RESPONSE_MESSAGE @"message"
#define RESPONSE_SUCCESS @"success"

//Login Service Response
#define USER_ID @"UserID"
//need to confirm
#define USER_FNAME @"FirstName"
#define USER_EMAIL @"EmailId"
#define USER_ROLE @"UserType"
#define USER_NAME @"Username"
#define LOGIN_BY @"LoginBy"
#define USER_NAME_CACHE_KEY @"UserName"
#define PASSWORD_CACHE_KEY @"Password"

#define USER_MOBILE @"MobileNumber"


#define PICKUP_ADDRESS_AVILBTY @"PickupAddressAvailable"
#define DELIVERY_ADDRESS_AVILBTY @"DeliveryAddressAvailable"

#define LOGIN_BY_SPINNPRESS @"loginbyspinnpress"
//Custom Importers
#import "MBProgressHUD.h"


@interface Global : NSObject
{
//Loader
MBProgressHUD *HUD;

}

+ (Global *)sharedInstance;


//Global Get Set Values
-(id)getGlobalValueFor : (NSString *)strKeyValue;
-(void)setGlobalValue : (id) IdValue For :(NSString *)strKeyValue;

//- (BOOL)isNetAvailable;

//Loader Methods
- (void)showLoaderOnView:(NSString*)strTitle view:(UIView*)v;
- (void)showLoaderOnWindow:(NSString*)strTitle view:(UIView*)v;
- (void)hideLoader;

//- (void)saveUserName:(NSString *)userName;
//- (void)savePassword:(NSString *)password;
//- (NSString *)getUserNameFromCache;
//- (NSString *)getPasswordFromCache;
//- (void)removeKeysWhenUserLogout;
- (NSInteger)getiPhoneVersion;


//Devicetokens methods
//-(void)setDeviceToken :(NSString *)strDeviceToken;
//-(NSString *)getDeviceToken;

//-(void)ManagePushNotification;
-(void)UploadDeviceTokenInBackground;


//Internet Validation
-(BOOL)ValidateInternet;

-(void)setDeviceTokenUploadedStatus : (BOOL)UploadStatus;
-(BOOL)IsDeviceTokenUploaded;


//Save and get UserId
- (void)saveUserIdInCache:(NSString *)userId;
- (NSString *)getUserIdFromCache;


-(BOOL)isLoaderVisible;
@end
