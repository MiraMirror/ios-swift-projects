//
//  Global.m
//  SpinNPress
//
//  Created by bviadmin on 11/11/14.
//  Copyright (c) 2014 BrainVire. All rights reserved.
//

#import "Global.h"

@implementation Global

static NSMutableDictionary *dicGlobal;
//static BOOL __isLoaderVisible;

+ (Global *)sharedInstance
{
    static Global *sharedInstance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
        dicGlobal = [[NSMutableDictionary alloc]initWithCapacity:0];
//        __isLoaderVisible = FALSE;
        // Do any other initialisation stuff here
    });
    return sharedInstance;
}

//Global Get Set Values
-(id)getGlobalValueFor : (NSString *)strKeyValue
{
    return [dicGlobal valueForKey:strKeyValue];
}
-(void)setGlobalValue : (id) IdValue For :(NSString *)strKeyValue
{
    [dicGlobal setObject:IdValue forKey:strKeyValue];
}

#pragma mark-a Loader
- (void)showLoaderOnView:(NSString*)strTitle view:(UIView*)v
{
//incase of problem you can activate this
    dispatch_async(dispatch_get_main_queue() , ^{
        HUD = [[MBProgressHUD alloc] initWithView:v.window];
//        __isLoaderVisible = TRUE;
        [v.window addSubview:HUD];
        [HUD setDelegate:(id<MBProgressHUDDelegate>)self];
        HUD.labelText = strTitle;
        
        [HUD show:YES];
        
    });
}

- (void)showLoaderOnWindow:(NSString*)strTitle view:(UIView*)v
{
    HUD = [[MBProgressHUD alloc] initWithView:v.window];
//    __isLoaderVisible = TRUE;
    [v.window addSubview:HUD];
    
    [HUD setDelegate:(id<MBProgressHUDDelegate>)self];
    HUD.labelText = strTitle;
    [HUD show:YES];
    
}
- (void)hideLoader
{
    
    [HUD hide:YES];
//    __isLoaderVisible = FALSE;
    dispatch_async(dispatch_get_main_queue() , ^{
        [HUD removeFromSuperview];
        
        
        HUD = nil;
    });
    
    
}

- (void)hudWasHidden:(MBProgressHUD *)hud{
    
    [hud removeFromSuperViewOnHide];
//    __isLoaderVisible = FALSE;
    
}



@end
