//
//  AppDelegate.h
//  Snaap
//
//  Created by pratikjain on 27/01/15.
//  Copyright (c) 2015 pratik jain. All rights reserved.
//

#import <UIKit/UIKit.h>


@class DACircularProgressView;
@class DALabeledCircularProgressView;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property BOOL isFromCancel,isSavedPhoto;

+(AppDelegate *)shredDelegate;
@end

