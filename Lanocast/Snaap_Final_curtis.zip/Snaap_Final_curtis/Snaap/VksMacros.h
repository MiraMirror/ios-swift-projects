

#define Vks_LOAD_VIEW() \
NSBundle *mainBundle = [NSBundle mainBundle]; \
NSArray *views = [mainBundle loadNibNamed:NSStringFromClass([self class]) owner:self options:nil]; \
[self addSubview:views[0]];

#define Vks_Integer(value) [NSNumber numberWithInt:value]

#define Vks_INIT_OR_RETURN_NIL() \
self = [super init]; \
if (!self) { \
return nil; \
}

#define Vks_IF_NOT_SELF_RETURN_NIL() \
if (!self) { \
return nil; \
}

#define Vks_RETURN_IF_NIL(obj) \
if (!obj) { \
return nil; \
}