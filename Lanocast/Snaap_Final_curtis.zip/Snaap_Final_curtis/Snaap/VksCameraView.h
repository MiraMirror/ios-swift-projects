//
////
//#import <UIKit/UIKit.h>
//#import <Foundation/Foundation.h>
//#import <AVFoundation/AVFoundation.h>
//
//
///**
// Defines a key for the "meta" dictionary as returned in VksCameraViewDelegate#cameraView:didFinishTakingPicture:withInfo:meta
// 
// @see VksCameraViewMetaCrop
// @see VksCameraViewMetaOriginalImage
// */
//typedef NSString* VksCameraViewMeta;
//
///**
// Key to get a CGRect object, the rectangle in which the full resolution image was cropped at.
// */
//extern VksCameraViewMeta const VksCameraViewMetaCrop;
//
///**
// Key to get a UIImage object, the full resolution image as taken by the camera.
// */
//extern VksCameraViewMeta const VksCameraViewMetaOriginalImage;
//
//@class VksCameraView;
//
//@protocol VksCameraViewDelegate <NSObject>
//
///**
// Implement to get a callaback on the main thread with the image on VksCameraView#takePicture: only if an error didn't 
// occur.
// 
// @param cameraView the VksCameraView intance that this delegate is assigned to
// @param image the square cropped image in JPG format using, its size is the maximum used to capture it, its orientation is preserved from the camera.
// @param info
// @param meta
// @see VksCameraViewMeta
// */
//-(void)cameraView:(VksCameraView*)cameraView didFinishTakingPicture:(UIImage *)image withInfo:(NSDictionary*)info meta:(NSDictionary *)meta;
//
///**
// Implement to get a callaback on the main thread if an error occurs on VksCameraView#takePicture:
// 
// @param cameraView the VksCameraView intance that this delegate is assigned to
// @param error the error as returned by AVCaptureSession#captureStillImageAsynchronouslyFromConnection:completionHandler:
// */
//-(void)cameraView:(VksCameraView *)cameraView didErrorOnTakePicture:(NSError *)error;
//
//@optional
///**
// Implement if VksCameraView.callbackOnDidCreateCaptureConnection is set to YES.
// 
// Will get a callback to customise the underlying AVCaptureConnection when created.
// 
// AVCaptureConnection has the following properties already set:
//
//    videoOrientation = AVCaptureVideoOrientationPortrait;
// 
// @param cameraView the VksCameraView instance this delegate is assigned to
// @param captureConnection the AVCaptureConnection instance that will be used to capture the image
// @see AVCaptureSession#captureStillImageAsynchronouslyFromConnection:completionHandler:
// */
//-(void)cameraView:(VksCameraView*)cameraView didCreateCaptureConnection:(AVCaptureConnection*)captureConnection;
//
///**
// Implement if VksCameraView.allowPictureRetake is set to YES.
// 
// Will get a callaback with the image as returned by the last call to #cameraView:didFinishTakingPicture:info:meta
// 
// @param cameraView the VksCameraView intance that this delegate is assigned to.
// @param image current image currently previewing.
// */
//-(void)cameraView:(VksCameraView*)cameraView willRetakePicture:(UIImage *)image;
//
///**
// Implement if VksCameraView.writeToCameraRoll is set to YES.
// 
// Will get a callback before writing the image to the camera roll as taken in full resolution by the camera.
// 
// @param cameraView the VksCameraView instance this delegate is assigned to
// @param metadata the metadata instance that will be used to capture the image
// */
//-(void)cameraView:(VksCameraView*)cameraView willRriteToCameraRollWithMetadata:(NSDictionary *)metadata;
//
//@end
//
///**
// A UIView that displays a live feed of AVMediaTypeVideo and can capture a still image from it.
// 
// 
// 
// The view controller that has VksCameraView in its hierarchy should set the image from cameraView:didFinishTakingPicture:editingInfo #preview.image on #viewWillAppear
//
// Portrait, iPhone only orientation
// @see 
// */
//@interface VksCameraView : UIView <VksCameraViewDelegate>
//
///**
// Set to true to get a callaback to configure AVCaptureConnection
// 
// @precondition have delegate set
// @precondition have cameraView:didCreateCaptureConnection: implemented
// */
//@property(nonatomic, assign) BOOL callbackOnDidCreateCaptureConnection;
//
///**
// Set to true to allow the user to retake a photo by tapping on the preview
// 
// @precondition have delegate set
// @precondition have cameraView:didCreateCaptureConnection: implemented
// */
//@property(nonatomic, assign) BOOL allowPictureRetake;
//
//
/////
//@property(nonatomic, assign) BOOL writeToCameraRoll;
//
//
///**
// 
// */
//@property(nonatomic, assign) IBOutlet NSObject<VksCameraViewDelegate>* delegate;
//
//
///**
// Set backgroundColor to a custom one
// 
//    backgroundColor = [UIColor whiteColor];
// 
// */
//@property(nonatomic, strong) UIView *flashView;
//@property(nonatomic) AVCaptureWhiteBalanceMode whiteBalanceMode;
//
///**
// Takes a still image of the current frame from the video feed.
// 
// Does not block.
// 
// @callback on the main thread at VksCameraViewDelegate#cameraview:didFinishTakingPicture:editingInfo once the still image is processed.
// */
//- (void)takePicture;
//
///**
// 
// Restart the take picture session as if the user had tapped on the view with the VksCameraView#allowPictureRetake property set to YES. 
// 
// Does not block.
//
// @callback on the main thread at VksCameraViewDelegate#cameraView:willRetakePicture:
// */
//- (void) retakePicture;
//
//-(void)Refresh;
//@end
