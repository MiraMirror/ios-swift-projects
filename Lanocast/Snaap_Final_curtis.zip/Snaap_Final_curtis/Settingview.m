//
//  Settingview.m
//  Snaap
//
//  Created by pratikjain on 27/01/15.
//  Copyright (c) 2015 pratik jain. All rights reserved.
//

#import "Settingview.h"
#import "Mainview.h"
#import <social/social.h>

@interface Settingview ()<UIImagePickerControllerDelegate,UIDocumentInteractionControllerDelegate>
{
    NSArray *array2;
    
}
@property (nonatomic, retain) UIDocumentInteractionController *dic;


@end

@implementation Settingview
{
    UIActionSheet *sharesheet, *email_sheet;
    UISlider *slider;
}




- (void)viewDidLoad
{
    
    
    
    [super viewDidLoad];
    
    slider.value=0;
    
    CGRect myFrame = CGRectMake(35.0f, 10.0f, 150.0f, 25.0f);
    
    slider = [[UISlider alloc]initWithFrame:myFrame];

    slider.minimumValue=0;
    slider.maximumValue=3;
    slider.tintColor=[UIColor yellowColor];
    

    
    NSInteger intPrevValue = [[[NSUserDefaults standardUserDefaults]valueForKey:SLIDER_VALUE]integerValue];
    [slider setValue:intPrevValue animated:YES];
    
    [slider addTarget:self action:@selector(slidertimevaluechanged:) forControlEvents:UIControlEventValueChanged];
    slider.continuous=YES;
    
    sharesheet=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"cancel" destructiveButtonTitle:nil otherButtonTitles:@"Facebook",@"Instagram", nil];
    
    email_sheet=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"cancel" destructiveButtonTitle:nil otherButtonTitles: @"Support",@"Feedback", nil];
    
    
    
    // Do any additional setup after loading the view.
    //[act_sheet addTarget:self action:@selector(showActionSheet:) forControlEvents:ui];
    
    array2=[[NSArray alloc]initWithObjects:@"Rate Lanocast",@"Share To Facebook",@"Share To Instagram",@"Support & Feedback",@"", nil];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.tvo.tableFooterView = [[UIView alloc] init] ;
    UIView *view1= [[UIView alloc]init];
    view1.backgroundColor=[UIColor colorWithRed:67.0/255.0 green:80.0/255.0 blue:105.0/255.0 alpha:1];
    [self.tvo setBackgroundView:view1];
    self.tvo.separatorColor = [UIColor colorWithRed:67.0/255.0 green:80.0/255.0 blue:105.0/255.0 alpha:1.0];
    

    [self.view setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:80.0/255.0 blue:105.0/255.0 alpha:1.0]];

    
}

-(void)slidertimevaluechanged:(UISlider *)__slider
{
    
    NSInteger roundValue = round(__slider.value);
    [__slider setValue:roundValue animated:NO];
    
    [[NSUserDefaults standardUserDefaults]setObject:[NSNumber numberWithInteger:roundValue] forKey:SLIDER_VALUE];
    [[NSUserDefaults standardUserDefaults]synchronize];
    [GLOBAL setGlobalValue:[NSNumber numberWithInteger:roundValue] For:SLIDER_VALUE];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [email_sheet reloadInputViews];
    if (actionSheet == email_sheet)
    {
        
        if (buttonIndex == 0|| buttonIndex == 1)
        {
            
        NSString *StrEmail = nil;
        NSString *strSub = nil;
    
        
    if (buttonIndex == 0)//support

    {
        
        StrEmail = @"support@lanocast.com";
        strSub = @"Support Team";
    }
            
            
    else if( buttonIndex == 1 )//feedback
    {
        
        
        StrEmail = @"feedback@lanocast.com";
        strSub = @"FeedBack Team";

    }
            
        if ([MFMailComposeViewController canSendMail])
        {
            MFMailComposeViewController *mailer1 = [[MFMailComposeViewController alloc] init];
            mailer1.mailComposeDelegate = self;
            
            NSArray *toRecipients = [NSArray arrayWithObjects:StrEmail, nil];
            [mailer1 setToRecipients:toRecipients];
            [mailer1 setSubject:strSub];
            
            NSMutableString *emailBody1 = [[NSMutableString alloc] initWithString:@"<html><body>"];
            
            [emailBody1 appendString:@"</body></html>"];
            
            NSString *str = @"";
            str = [str stringByAppendingString:@"<br>"];
            str = [str stringByAppendingString:@"<br>"];
            str = [str stringByAppendingString:@"<br>"];
            str = [str stringByAppendingString:@"Device : "];
            str = [str stringByAppendingString:[UIDevice currentDevice].systemName];
            str = [str stringByAppendingString:@"<br>"];
            str = [str stringByAppendingString:@"Firmware Version : "];
            str = [str stringByAppendingString:@" iOS "];
            str = [str stringByAppendingString:[UIDevice currentDevice].systemVersion];
            str = [str stringByAppendingString:emailBody1];
            NSLog(@"%@",str);
            [mailer1 setMessageBody:str isHTML:YES];
            mailer1.modalPresentationStyle =UIModalPresentationFormSheet;
            mailer1.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
            
            if (mailer1)
                [self presentViewController:mailer1 animated:YES completion:^{}];
        }
            
        else
         
        {
            [self launchMailAppOnDevice:StrEmail :strSub];
        }
            
        }

}

}



-(void)launchMailAppOnDevice :(NSString *)strEmail :(NSString *)strSub
{
    NSString *recipients = [NSString stringWithFormat:@"mailto:%@?subject=%@",strEmail,strSub];
    NSString *emailBody = @"";
    NSString *email = [NSString stringWithFormat:@"%@%@", recipients, emailBody];
    email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    UIAlertView *alert;
    switch (result)
    {
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            break;
        case MFMailComposeResultSent:
            alert = [[UIAlertView alloc] initWithTitle:@"Message!" message:@"Mail Sent Successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            break;
        case MFMailComposeResultFailed:
            
            break;
        default:
            break;
    }
    
    [self dismissViewControllerAnimated:YES completion:^{}];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}
- (BOOL)shouldAutorotate
{
    
    //    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    //
    //    if (orientation == UIInterfaceOrientationPortrait) {
    //        // your code for portrait mode
    //
    //    }
    
    return YES;
}

-(BOOL)prefersStatusBarHidden {
    return NO;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (section==0)
    {
        return 2;
    } else if(section==1)
    {
        return [array2 count];
    }
    else
    {
        return 0;
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell1" forIndexPath:indexPath];
    [tableView setBackgroundColor:[UIColor blackColor]];
    // Configure the cell...
    if (indexPath.section==0)
    {
        if (indexPath.row==0)
        {
            cell.textLabel.text=@"Time Delay";
            [cell.textLabel setFont:[UIFont fontWithName:@"DIN Condensed" size:20.0]];
            cell.userInteractionEnabled=NO;
        }
        else
        {
            UILabel *zero=[[UILabel alloc]initWithFrame:CGRectMake(20, 10, 30, 25)];
            zero.text=@"0";
            zero.textColor=[UIColor whiteColor];
            [cell addSubview:zero];
            
            [cell addSubview:slider];
            
            UILabel *three=[[UILabel alloc]initWithFrame:CGRectMake(190, 10, 30, 25)];
            three.text=@"3";
            three.textColor=[UIColor whiteColor];
            [cell addSubview:three];
            UILabel *secs=[[UILabel alloc]initWithFrame:CGRectMake(203, 13, 60, 25)];
            secs.text=@"(Secs)";
            [secs setFont:[UIFont fontWithName:@"DIN Condensed" size:20.0]];
            secs.textColor=[UIColor whiteColor];
            [cell addSubview:secs];
        }
    }
    else if (indexPath.section==1)
    {
   
        if (indexPath.row==4)
        {
            UIImageView *img=[[UIImageView alloc]initWithFrame:CGRectMake(90, 0, 30, 28)];
            img.image=[UIImage imageNamed:@"twitter_new.png"];
            [cell addSubview:img];
            UILabel *footer=[[UILabel alloc]initWithFrame:CGRectMake(118, 6, 100, 25)];
            footer.text=@"@lanocast";
            [footer setFont:[UIFont fontWithName:@"DIN Condensed" size:20.0]];
            footer.textColor=[UIColor whiteColor];
            cell.userInteractionEnabled=NO;
            
            cell.separatorInset = UIEdgeInsetsMake(0, cell.bounds.size.width, 0, 0);
            
            
            //cell.textLabel.backgroundColor=[UIColor colorWithRed:67.0/255.0 green:80.0/255.0 blue:105.0/255.0 alpha:1.0];


            [cell addSubview:footer];
        }
        cell.textLabel.text=[array2 objectAtIndex:indexPath.row];
        [cell.textLabel setFont:[UIFont fontWithName:@"DIN Condensed" size:20.0]];
        
    }
    [cell.textLabel setTextColor:[UIColor whiteColor]];
    
    
    return cell;
}
- (void)tableView: (UITableView*)
tableView willDisplayCell: (UITableViewCell*)cell
forRowAtIndexPath: (NSIndexPath*)indexPath
{
    
    if (indexPath.row>4)
    {
        cell.hidden=YES;
        //self.tvo.tableFooterView = [[UIView alloc] init] ;
        
    }
    cell.backgroundColor =[UIColor colorWithRed:44.0/255.0 green:51.0/255.0 blue:70.0/255.0 alpha:1];
    if (indexPath.row==4)
    {
        cell.backgroundColor =[UIColor colorWithRed:67.0/255.0 green:80.0/255.0 blue:105.0/255.0 alpha:1];
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
{
    return 64;
}
/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
 } else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
 {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

-(NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskAll;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 64)];
    // Background color
    headerView.backgroundColor = [UIColor colorWithRed:67.0/255.0 green:80.0/255.0 blue:105.0/255.0 alpha:1.0];
    
    // Text Color
    float width = 20.0f;
    UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(width, width, tableView.frame.size.width-width, 64.0f-width)];
    [lbl setBackgroundColor:[UIColor clearColor]];
    lbl.textColor = [UIColor colorWithRed:102.0/255.0 green:115.0/255.0 blue:134.0/255.0 alpha:1];
    lbl.font = [UIFont fontWithName:@"DIN Condensed" size:20.0];
    if (section==0)
    {
        lbl.text = @"LANOCAST SETTINGS";
    } else {
        lbl.text =@"LOVE OUR APP";
    }
    
    [headerView addSubview:lbl];
    return headerView;
    
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
   
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    
    if(indexPath.section==1)
    {
        
        if (indexPath.row==0)
        {
            
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Will Be Done When App is Live"
//                                                        message:nil
//                                                        delegate:self
//                                                        cancelButtonTitle:@"OK"
//                                                        otherButtonTitles:nil];
//            
//            [alert show];
            
            NSString *iTunesLink = @"itms://itunes.apple.com/us/app/lanocast/id964851695?ls=1&mt=8";
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
            
        }

        
        else if (indexPath.row==1)
        {
            
            [self fbshare];
            ///fb sharing will be here
            
        }
        else if (indexPath.row==2)
        {
            
            [self instagramshare];
            ///instagram sharing will be here
            
        }
        
        else  if (indexPath.row==3)
        {
            
            
            if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
                
                NSIndexPath *vvv =[NSIndexPath indexPathForRow:2 inSection:1];
                
                
                
                CGRect frame = vvv.accessibilityFrame;

                // In this case the device is an iPad.
                
                //[email_sheet showFromRect:[self.view frame] inView:self.view animated:YES];
                CGRect myImageRect = CGRectMake(frame.origin.x, frame.origin.y, 160.0f, 640.0f);
                
                
                
                [email_sheet showFromRect:myImageRect inView:self.view animated:NO];
        }
            
            else{
                
                // In this case the device is an iPhone/iPod Touch.
                
                [email_sheet showInView:self.view];
                
            }
        }
        
    }
    
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

- (void)didEnterBackground:(NSNotification *)notification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UITextFieldTextDidChangeNotification
                                                  object:nil];
    [self.presentedViewController dismissViewControllerAnimated:NO completion:nil];
}

- (void)fbshare
{
    
    UIImage *imgeToShare =nil;
    
    
    NSData* myEncodedImageData = [[NSUserDefaults standardUserDefaults]valueForKey: LAST_IMAGE];
    imgeToShare = [UIImage imageWithData:myEncodedImageData];
    
    if (myEncodedImageData!=nil)
    {
        
        if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
        {
           SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
            
            [controller setInitialText:@""];
            
            [controller addImage:[UIImage imageWithData:myEncodedImageData]];
            
            [self presentViewController:controller animated:YES completion:Nil];
            
        }
        else
        {
            UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"you are not logged in" message:nil delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alrt show];
        }
    }
    
}

- (void)instagramshare
{
    
    NSData* myEncodedImageData = [[NSUserDefaults standardUserDefaults]valueForKey: LAST_IMAGE];
    UIImage *imgeToShare = [UIImage imageWithData:myEncodedImageData];
    
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://location?id=1"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
       //[[UIApplication sharedApplication] openURL:instagramURL];
    
    NSString* imagePath = [NSString stringWithFormat:@"%@/image.igo", [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]];
    [[NSFileManager defaultManager] removeItemAtPath:imagePath error:nil];
    [UIImagePNGRepresentation(imgeToShare) writeToFile:imagePath atomically:YES];
    NSLog(@"image size: %@", NSStringFromCGSize(imgeToShare.size));
    _docController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:imagePath]];
    _docController.delegate=self;
    _docController.UTI = @"com.instagram.exclusivegram";
    [_docController presentOpenInMenuFromRect:self.view.frame inView:self.view animated:YES];
    
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"no instagram installed"
                                                       message:@""
                                                      delegate:nil
                                             cancelButtonTitle:@"Ok"
                                             otherButtonTitles: nil];
        
                [alert show];
    }
    
}
//- (void)shareToSocialNetwork
//{
//    // start activity indicator
////    NSString *string = @"Snaap Image";
////    NSURL *URL = [NSURL URLWithString:string];
//    
//    
//    //vks comeback place the image to share
//    UIImage *imgeToShare =nil;
//    
//    //static
//    /////////imgeToShare = [UIImage imageNamed:@"twitter_new.png"];
//    
//   NSData* myEncodedImageData = [[NSUserDefaults standardUserDefaults]valueForKey: LAST_IMAGE];
//   imgeToShare = [UIImage imageWithData:myEncodedImageData];
//    
//    if (imgeToShare!= nil)
//        
//    {
//    
//    NSData *compressedImage = UIImageJPEGRepresentation(imgeToShare, 0.9 );
//    NSString *docsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
//    NSString *imagePath = [docsPath stringByAppendingPathComponent:@"image.jpg"];
//    NSURL *imageUrl = [NSURL fileURLWithPath:imagePath];
//    
//    [compressedImage writeToURL:imageUrl atomically:YES];
//    
//    
//    
//    
//    [GLOBAL showLoaderOnView:@"Loading" view:self.view];
//    
//    // create new dispatch queue in background
//    dispatch_queue_t queue = dispatch_queue_create("openActivityIndicatorQueue", NULL);
//    
//    
//    // send initialization of UIActivityViewController in background
//    dispatch_async(queue, ^{
//        
//        DMActivityInstagram *instagramActivity = [[DMActivityInstagram alloc] init];
//        NSString *shareText = @"Snaap Picture";
//        NSURL *shareURL = [NSURL URLWithString:@"support@snaap.com"];
//        
//        NSArray *activityItems = @[imgeToShare, shareText, shareURL];
//        UIActivityViewController *activityController = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:@[instagramActivity]];
//        
//        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
//        {
//            [self presentViewController:activityController animated:YES completion:nil];
//        }
//        //if iPad
//        else
//        {
//            // Change Rect to position Popover
//            UIPopoverController *popup = [[UIPopoverController alloc] initWithContentViewController:activityController];
//            NSLog(@"%f",self.view.frame.size.width/2);
//            NSIndexPath *vvv =[NSIndexPath indexPathForRow:1 inSection:1];
//            
//            
//            
//            CGRect frame = vvv.accessibilityFrame;
//            [popup presentPopoverFromRect:CGRectMake(frame.origin.x, frame.origin.y, 160.0f, 560.0f)inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
//        }
//       
//        
//        
//       // [self presentViewController:activityController animated:YES completion:nil];
//        
////        
////        
////        
////        
////        
////        UIActivityViewController *activityViewController =
////        [[UIActivityViewController alloc] initWithActivityItems:@[string, imageUrl]
////                                          applicationActivities:nil];
//        
//        dispatch_async(dispatch_get_main_queue(), ^{
//            
//            [GLOBAL hideLoader];
//            
//            //[self presentViewController:activityController animated:YES completion:nil];
//        });
//    });
//        }
//   else
//    {
//        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Snaap" message:@"No image Available to share" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
//        [alert show];
//    }
//    
//    
//}



@end
