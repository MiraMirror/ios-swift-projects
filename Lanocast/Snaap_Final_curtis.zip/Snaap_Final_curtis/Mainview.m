//
//  Mainview.m
//  Snaap
//
//  Created by pratikjain on 27/01/15.
//  Copyright (c) 2015 pratik jain. All rights reserved.
//

#import "Mainview.h"

#import <RapidEars/OEPocketsphinxController+RapidEars.h>
#import <Rejecto/OELanguageModelGenerator+Rejecto.h>



#import <OpenEars/OELanguageModelGenerator.h>
#import <OpenEars/OEAcousticModel.h>
#import <OpenEars/OEPocketsphinxController.h>
#import <OpenEars/OEFliteController.h>
#import <OpenEars/OELogging.h>
#import <Slt/Slt.h>

#import <AVFoundation/AVFoundation.h>
#import "SCSiriWaveformView.h"
#import "AppDelegate.h"


#define DegreesToRadians(x) ((x) * M_PI / 180.0)

@interface Mainview () // <DynamicSpeechRecognitionDelegate>
{
    UISwitch *myswitch;
    
}

@property (nonatomic) BOOL flag;
@property (strong, nonatomic) IBOutlet UILabel *display;
@property (strong, nonatomic) IBOutlet UILabel *displayHint;
//@property (nonatomic, strong) DynamicSpeechRecognition *voiceRecognition;
@property (nonatomic, strong) AVAudioRecorder *recorder;

@property (nonatomic, weak) IBOutlet SCSiriWaveformView *waveformView;

@end

@implementation Mainview
{
    UIButton *btnCameraClose ;
}

AVAudioPlayer *_a6;



@synthesize openEarsEventsObserver;
@synthesize  take_picker;
@synthesize pathToFirstDynamicallyGeneratedLanguageModel;
@synthesize pathToFirstDynamicallyGeneratedDictionary;
@synthesize restartAttemptsDueToPermissionRequests;
@synthesize startupFailedDueToLackOfPermissions;
//@synthesize stillImageOutput, captureImage;

bool isFirstRun = true;



- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.take_pic_label.hidden=FALSE;
    self.snap_label.hidden=FALSE;
    
    self.btnRetake.hidden = TRUE;
    
    [NSTimer scheduledTimerWithTimeInterval:5.0
                                     target:self
                                   selector:@selector(star_camara)
                                   userInfo:nil
                                    repeats:NO];
    
    
    //self.star.frame=CGRectMake(self.view.frame.size.width-220,self.view.frame.size.height-120 , 120, 40);
    
    
    NSString *str6 = [NSString stringWithFormat:@"%@/string6_e.mp3", [[NSBundle mainBundle] resourcePath]];
    
    
    NSURL *sl6 = [NSURL fileURLWithPath:str6];
    
    // Create audio player object and initialize with URL to sound
    
    _a6 = [[AVAudioPlayer alloc] initWithContentsOfURL:sl6 error:nil];
    
    
    // self.waveformView.frame=CGRectMake(0,8,self.view.frame.size.width,24);//////wavelength
    
    
    
    //[self.navigationController.view addSubview:self.waveformView];
    
    //    NSURL *url = [NSURL fileURLWithPath:@"/dev/null"];
    //
    //    NSDictionary *settings = @{AVSampleRateKey:          [NSNumber numberWithFloat: 44100.0],
    //                               AVFormatIDKey:            [NSNumber numberWithInt: kAudioFormatAppleLossless],
    //                               AVNumberOfChannelsKey:    [NSNumber numberWithInt: 2],
    //                               AVEncoderAudioQualityKey: [NSNumber numberWithInt: AVAudioQualityMin]};
    //
    //    NSError *error;
    //
    //    self.recorder = [[AVAudioRecorder alloc] initWithURL:url settings:settings error:&error];
    //
    //    if(error) {
    //        NSLog(@"Ups, could not create recorder %@", error);
    //        return;
    //    }
    //
    //    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:&error];
    //
    //    if (error)
    //    {
    //        NSLog(@"Error setting category: %@", [error description]);
    //    }
    //
    //    [self.recorder prepareToRecord];
    //    [self.recorder setMeteringEnabled:YES];
    //    [self.recorder record];
    //
    //    CADisplayLink *displaylink = [CADisplayLink displayLinkWithTarget:self selector:@selector(updateMeters)];
    //
    //    [displaylink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
    //
    //
    
    //[self.waveformView setWaveColor:[UIColor whiteColor]];
    // [self.waveformView setPrimaryWaveLineWidth:3.0f];
    // [self.waveformView setSecondaryWaveLineWidth:1.0];
    
    
    
    myswitch=[[UISwitch alloc]initWithFrame:CGRectMake(0, 10, 30, 50)];
    [myswitch addTarget:self action:@selector(on_off:) forControlEvents:UIControlEventValueChanged];
    
    //self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView: myswitch]    ;
    
    
    
    self.restartAttemptsDueToPermissionRequests = 0;
    self.startupFailedDueToLackOfPermissions = FALSE;
    
    
    self.openEarsEventsObserver = [[OEEventsObserver alloc] init];
    [self.openEarsEventsObserver setDelegate:self];
    
    OELanguageModelGenerator *languageModelGenerator = [[OELanguageModelGenerator alloc] init];
    
    NSArray *words = [NSArray arrayWithObjects:@"SNAP",@"LANO",@"LENO", nil];
    NSString *name = @"FirstOpenEarsDynamicLanguageModel";
    // NSError *err = [languageModelGenerator generateLanguageModelFromArray:words withFilesNamed:name forAcousticModelAtPath:[OEAcousticModel pathToModel:@"AcousticModelEnglish"]];
    NSError *err = [languageModelGenerator generateRejectingLanguageModelFromArray:words
                                                                    withFilesNamed:name
                                                            withOptionalExclusions:nil
                                                                   usingVowelsOnly:FALSE
                                                                        withWeight:nil
                                                            forAcousticModelAtPath:[OEAcousticModel pathToModel:@"AcousticModelEnglish"]]; // Change "AcousticModelEnglish" to "AcousticModelSpanish" to create a Spanish Rejecto model.
    
    
    
    if([err code] != noErr)
    {
        NSLog(@"Dynamic language generator reported error %@", [err description]);
    }
    else
    {
        self.pathToFirstDynamicallyGeneratedLanguageModel = [languageModelGenerator pathToSuccessfullyGeneratedLanguageModelWithRequestedName:name];
        self.pathToFirstDynamicallyGeneratedDictionary = [languageModelGenerator pathToSuccessfullyGeneratedDictionaryWithRequestedName:name];
        
        NSLog(@"Dynamic language generator completed successfully, you can find your new files at the paths \n%@ \nand \n%@",self.pathToFirstDynamicallyGeneratedLanguageModel,self.pathToFirstDynamicallyGeneratedDictionary);
    }
    
    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_6_1)
    {
        // iOS 6.1 or earlier
        self.navigationController.navigationBar.tintColor = [UIColor yellowColor];
    }
    else
    {
        // iOS 7.0 or later
        self.navigationController.navigationBar.barTintColor = [UIColor yellowColor];
        self.navigationController.navigationBar.translucent = NO;
    }
    
    [myswitch setOn:YES animated:YES];
    
    //[self.voiceRecognition startVoiceRecognition];
    
    // Do any additional setup after loading the view.
    self.flag = YES;
    //self.voiceRecognition.delegate = self;
    
    
    
    
    
    ////////////////uncomment if require/////
    SWRevealViewController *revealViewController = self.revealViewController;
    
    if(revealViewController)
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector(revealToggle:)];
        [self.revealViewController setDelegate:(id<SWRevealViewControllerDelegate>)self];
        [revealViewController setTempdelegate:self];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    
    //
    //
    //
    //    dispatch_async(dispatch_get_main_queue(), ^
    //    {
    //
    //    });
    //}
    //
    //-(void)OrientationDidChange:(NSNotification*)notification
    //{
    //    UIDeviceOrientation Orientation=[[UIDevice currentDevice]orientation];
    //
    //    if(Orientation==UIDeviceOrientationLandscapeLeft || Orientation==UIDeviceOrientationLandscapeRight)
    //    {
    //   self.waveformView.frame=CGRectMake(13,20,self.view.frame.size.width,24);///landscape size of waves
    //        [self.navigationController.view addSubview:self.waveformView];
    //
    //
    //
    //
    //
    //    }
    //     else if (Orientation==UIDeviceOrientationPortrait)
    //    {
    //  self.waveformView.frame=CGRectMake(0,8,self.view.frame.size.width,24);////portrait size of waves
    //        [self.navigationController.view addSubview:self.waveformView];
    //
    //
    //    }
    //}
    //
    //
    //- (void)updateMeters
    //{
    //    [self.recorder updateMeters];
    //
    //    CGFloat normalizedValue = pow (10, [self.recorder averagePowerForChannel:0] / 20);
    //
    //    [self.waveformView updateWithLevel:normalizedValue];
    //}
}
- (void)revealController:(SWRevealViewController *)revealController willMoveToPosition:(FrontViewPosition)position
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       if(position == FrontViewPositionLeft)
                       {
                           [[OEPocketsphinxController sharedInstance] resumeRecognition];
                           //[self startButtonAction];
                           //[myswitch setOn:YES];
                       }
                       else if (position == FrontViewPositionRight)
                       {
                           //[self stopButtonAction];
                           [[OEPocketsphinxController sharedInstance] suspendRecognition];
                           //[myswitch setOn:FALSE];
                       }
                   });
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:NO];
    //[self performSelector:@selector(startButtonAction) withObject:nil afterDelay:0.1];
    self.show_anim.frame=CGRectMake(self.view.frame.size.width/2, self.view.frame.size.height/2, 50, 75);
    
    
}

-(void)open_camara
{
    take_picker = [[UIImagePickerController alloc] init];
    take_picker.delegate = self;
    take_picker.allowsEditing = YES;
    take_picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    take_picker.cameraDevice =   UIImagePickerControllerCameraDeviceFront;
    take_picker.showsCameraControls=NO;
    [self presentViewController:take_picker animated:YES completion:^{
        
        btnCameraClose = [[UIButton alloc]initWithFrame:CGRectMake(30, 30, 150, 30)];
        
        [btnCameraClose setTitle:@"Cancel" forState:UIControlStateNormal];
        [btnCameraClose setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        btnCameraClose.backgroundColor = [UIColor yellowColor];
        btnCameraClose.layer.cornerRadius = 5.0f;
        btnCameraClose.layer.masksToBounds = YES;
        [btnCameraClose addTarget:self action:@selector(Close_click) forControlEvents:UIControlEventTouchUpInside];
        [[AppDelegate shredDelegate].window addSubview:btnCameraClose];
    }];
}

-(void)wv
{
    
    [self performSegueWithIdentifier:@"ss1" sender:nil];
}

#pragma mark - Image Picker Controller delegate methods

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    self.take_pic_label.hidden=TRUE;
    self.snap_label.hidden=TRUE;
    self.btnRetake.hidden = TRUE;
    
    NSLog(@"photo captured page design");
    UIImage *chosenImage = info[UIImagePickerControllerOriginalImage];
    
    for(UIView *view in self.view.subviews)
    {
        if(view.tag == 1111 || view.tag == 1112)
            [view removeFromSuperview];
    }
    
    NSLog(@"Screen Width : %f Height : %f",[[UIScreen mainScreen] bounds].size.width,[[UIScreen mainScreen] bounds].size.height);
    
    NSLog(@"View Width : %f Height : %f",self.view.frame.size.width,self.view.frame.size.height);
    
    UIView *blackview1 = [[UIView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-120, self.view.frame.size.width, 120)];
    
    blackview1.backgroundColor=[UIColor blackColor];
    blackview1.tag = 1111;
    
    if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation))
    {
        NSLog(@"Landscape");
        blackview1.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.width-160, [[UIScreen mainScreen] bounds].size.height, 160);
    }
    else
    {
        NSLog(@"Portrait");
        blackview1.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-160, [[UIScreen mainScreen] bounds].size.width, 160);
    }
    
    UIButton *fb =[[UIButton alloc]initWithFrame:CGRectMake(10,12 , 40, 40)];
    UIImage *btnImage = [UIImage imageNamed:@"rsz_fb1.png"];
    [fb setImage:btnImage forState:UIControlStateNormal];
    [fb addTarget:self action:@selector(fbshare) forControlEvents:UIControlEventTouchUpInside];
    [blackview1 addSubview:fb];
    
    UIButton *instagrm =[[UIButton alloc]initWithFrame:CGRectMake(100,10 , 40, 45)];
    UIImage *btnImage2 = [UIImage imageNamed:@"rsz_insta.png"];
    [instagrm setImage:btnImage2 forState:UIControlStateNormal];
    [instagrm addTarget:self action:@selector(instagramshare) forControlEvents:UIControlEventTouchUpInside];
    [blackview1 addSubview:instagrm];
    
    UIButton *third =[[UIButton alloc]initWithFrame:CGRectMake(blackview1.frame.size.width - 50,10 , 40, 45)];
    
    
    if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation))
    {
        NSLog(@"Landscape");
        third.frame = CGRectMake([[UIScreen mainScreen] bounds].size.height-50, 10, 40, 45);
    }
    else
    {
        NSLog(@"Portrait");
        third.frame = CGRectMake([[UIScreen mainScreen] bounds].size.width-50, 10, 40, 45);
    }
    
    UIImage *btnImage3 = [UIImage imageNamed:@"link.png"];
    [third setImage:btnImage3 forState:UIControlStateNormal];
    [third addTarget:self
              action:@selector(wv)
    forControlEvents:UIControlEventTouchUpInside];
    [blackview1 addSubview:third];
    
    [self.view addSubview:blackview1];
    //
    //    UIButton *cam =[[UIButton alloc]initWithFrame:CGRectMake(187,10 , 47, 38)];
    //    UIImage *btnImage4 = [UIImage imageNamed:@"cam_icon.jpg"];
    //    [cam setImage:btnImage4 forState:UIControlStateNormal];
    //
    //    [blackview1 addSubview:cam];
    //
    //
    //    [cam addTarget:self
    //              action:@selector(open_camara)
    //    forControlEvents:UIControlEventTouchUpInside];
    
    UIView *blackview = [[UIView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-65, self.view.frame.size.width, self.view.frame.size.height/6)];
    
    blackview.backgroundColor=[UIColor blackColor];
    blackview.tag = 1112;
    
    UIButton *retake =[[UIButton alloc]initWithFrame:CGRectMake(15,72 , 59, 20)];
    
    [retake setTitle:@"Retake" forState:UIControlStateNormal];
    [retake setTintColor:[UIColor redColor]];
    [retake addTarget:self
               action:@selector(star_camara)
     forControlEvents:UIControlEventTouchUpInside];
    
    [blackview1 addSubview:retake];
    
    UIButton *usepic =[[UIButton alloc]initWithFrame:CGRectMake(third.frame.origin.x - 65,72,115,20)];
    
    [usepic setTitle:@"Save Photo" forState:UIControlStateNormal];
    
    [usepic setTintColor:[UIColor redColor]];
    [usepic addTarget:self
               action:@selector(SavePhoto)
     forControlEvents:UIControlEventTouchUpInside];
    
    [blackview1 addSubview:usepic];
    
    //  [self.view addSubview:blackview];
    
    self.captureImage.image = chosenImage;
    
    [[NSUserDefaults standardUserDefaults] setObject:UIImageJPEGRepresentation(self.captureImage.image, 1.0f) forKey:LAST_IMAGE];
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
    [self removeCancelButton];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (void)fbshare
{
    
    UIImage *imgeToShare =nil;
    imgeToShare = self.captureImage.image;
    
    if (imgeToShare!=nil)
    {
        
        if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
        {
            
            
            SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
            
            [controller setInitialText:@""];
            
            [controller addImage:imgeToShare];
            
            [self presentViewController:controller animated:YES completion:Nil];
            
        }
        else
        {
            UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"you are not logged in" message:nil delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alrt show];
        }
    }
    else
    {
        UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Please check your image." message:nil delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
        [alrt show];
    }
}

- (void)instagramshare
{
    
    NSData* myEncodedImageData = [[NSUserDefaults standardUserDefaults]valueForKey: LAST_IMAGE];
    UIImage *imgeToShare = [UIImage imageWithData:myEncodedImageData];
    
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://location?id=1"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
        //[[UIApplication sharedApplication] openURL:instagramURL];
        
        NSString* imagePath = [NSString stringWithFormat:@"%@/image.igo", [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]];
        [[NSFileManager defaultManager] removeItemAtPath:imagePath error:nil];
        [UIImagePNGRepresentation(imgeToShare) writeToFile:imagePath atomically:YES];
        NSLog(@"image size: %@", NSStringFromCGSize(imgeToShare.size));
        _docController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:imagePath]];
        _docController.delegate=self;
        _docController.UTI = @"com.instagram.exclusivegram";
        [_docController presentOpenInMenuFromRect:CGRectMake(0, self.view.frame.size.height - 150, 500, 500) inView:self.view animated:YES];
        
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"no instagram installed"
                                                       message:@""
                                                      delegate:nil
                                             cancelButtonTitle:@"Ok"
                                             otherButtonTitles: nil];
        
        [alert show];
    }
    
}



-(void)SavePhoto {
    
    if([AppDelegate shredDelegate].isSavedPhoto == NO)
    {
        UIImage *myImage = self.captureImage.image;
        if(myImage != nil)
        {
            NSString *myWatermarkText = @"Picture taken by Lanocast";
            UIImage *watermarkedImage = nil;
            NSDictionary *textAttributes = @{NSFontAttributeName: [UIFont systemFontOfSize:40.0], NSForegroundColorAttributeName :[UIColor whiteColor]};
            
            UIGraphicsBeginImageContext(myImage.size);
            [myImage drawAtPoint: CGPointZero];
            CGRect drawRect = CGRectMake(myImage.size.width/2 - 250.0f, myImage.size.height - 150.0f, 500.0, 100.0);
            [myWatermarkText drawInRect:drawRect withAttributes:textAttributes];
            watermarkedImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
            
            UIImageWriteToSavedPhotosAlbum(watermarkedImage, nil, nil, nil);
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"LANOCAST" message:@"Picture saved." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] ;
            [alert show];
            [AppDelegate shredDelegate].isSavedPhoto = YES;
        }
        
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"LANOCAST" message:@"Your photo already saved." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] ;
        [alert show];
    }
}

- (void) startListening
{
    [[OEPocketsphinxController sharedInstance] setActive:TRUE error:nil];
    
    [[OEPocketsphinxController sharedInstance] startRealtimeListeningWithLanguageModelAtPath:self.pathToFirstDynamicallyGeneratedLanguageModel dictionaryAtPath:self.pathToFirstDynamicallyGeneratedDictionary acousticModelAtPath:[OEAcousticModel pathToModel:@"AcousticModelEnglish"]];
    
    //[[OEPocketsphinxController sharedInstance] startListeningWithLanguageModelAtPath:self.pathToFirstDynamicallyGeneratedLanguageModel dictionaryAtPath:self.pathToFirstDynamicallyGeneratedDictionary acousticModelAtPath:[OEAcousticModel pathToModel:@"AcousticModelEnglish"] languageModelIsJSGF:NO];
}

- (void) pocketsphinxDidReceiveHypothesis:(NSString *)hypothesis recognitionScore:(NSString *)recognitionScore utteranceID:(NSString *)utteranceID
{
    NSLog(@"The received hypothesis is %@ with a score of %@ and an ID of %@", hypothesis, recognitionScore, utteranceID); // Log it.
    
    
    
    double recogScore = -1 * ([recognitionScore doubleValue]);
    
    
    if (recogScore > 500)
    {
        //snap detected
        // display the hypothesis in the you said: box
        
        
        NSString *strTold = [NSString stringWithFormat:@"\"%@\"", hypothesis];
        NSLog(@"Valid: %@",strTold);
        
        NSInteger slidervalue = [[GLOBAL getGlobalValueFor:SLIDER_VALUE]integerValue];
        
        if (slidervalue >0)
        {
            SliderCountDown = (int)slidervalue;
            
            [self stopButtonAction];
            
            //[self startAnimation];
            
            
            
        }
        else
        {
            
            // [self takeFinalCameraPic];
            
        }
        
    }
    
    else
    {
        
        // display the hypothesis in the you said: box
        NSString *strTold = [NSString stringWithFormat:@"\"%@\"", hypothesis];
        NSLog(@"InValid: %@",strTold);
    }
}


#ifdef kGetNbest
- (void) pocketsphinxDidReceiveNBestHypothesisArray:(NSArray *)hypothesisArray {
    NSLog(@"hypothesisArray is %@",hypothesisArray);
}
#endif

- (void) audioSessionInterruptionDidBegin
{
    NSLog(@"AudioSession interruption began.");
    
    [[OEPocketsphinxController sharedInstance] stopListening];
}

- (void) audioSessionInterruptionDidEnd
{
    NSLog(@"AudioSession interruption ended.");
    [self startListening];
}

- (void) audioInputDidBecomeUnavailable
{
    NSLog(@"The audio input has become unavailable");
    [[OEPocketsphinxController sharedInstance] stopListening];
}

- (void) audioInputDidBecomeAvailable {
    NSLog(@"The audio input is available");
    [self startListening];
}

- (void) audioRouteDidChangeToRoute:(NSString *)newRoute
{
    NSLog(@"Audio route change. The new audio route is %@", newRoute); // Log it.
    [[OEPocketsphinxController sharedInstance] stopListening];
    [self startListening];
}

- (void) pocketsphinxDidStartCalibration {
    NSLog(@"Pocketsphinx calibration has started.");
    
}

- (void) pocketsphinxDidCompleteCalibration {
    NSLog(@"Pocketsphinx calibration is complete.");
}

- (void) pocketsphinxRecognitionLoopDidStart {
    NSLog(@"Pocketsphinx is starting up.");
}

- (void) pocketsphinxDidStartListening {
    NSLog(@"Pocketsphinx is now listening.");
}

- (void) pocketsphinxDidDetectSpeech {
    NSLog(@"Pocketsphinx has detected speech.");
}

- (void) pocketsphinxDidDetectFinishedSpeech
{
    NSLog(@"Pocketsphinx has detected a second of silence, concluding an utterance.");
}

- (void) pocketsphinxDidStopListening {
    NSLog(@"Pocketsphinx has stopped listening.");
    
    
}

- (void) pocketsphinxDidSuspendRecognition
{
    NSLog(@"Pocketsphinx has suspended recognition.");
}

- (void) pocketsphinxDidResumeRecognition
{
    NSLog(@"Pocketsphinx has resumed recognition.");
    //hack-y method of preventing recognition after starting listening
    if (isFirstRun)
    {
        //[self suspendListeningButtonAction];
        //isFirstRun = FALSE;
    }
    else
    {
    }
}

- (void) pocketSphinxContinuousSetupDidFail
{
    NSLog(@"Setting up the continuous recognition loop has failed for some reason, please turn on [OpenEarsLogging startOpenEarsLogging] in OpenEarsConfig.h to learn more.");
}

- (void) testRecognitionCompleted
{
    NSLog(@"A test file which was submitted for direct recognition via the audio driver is done.");
    [[OEPocketsphinxController sharedInstance] stopListening];
}
///////////////////////////////////


-(void)zeronumber
{
    self.show_anim.hidden=YES;
    [take_picker takePicture];
    [self startButtonAction];
    
}

-(void)onenumber
{
    
    self.show_anim.hidden=NO;
    [take_picker.view addSubview:self.show_anim];
    [take_picker.view bringSubviewToFront:self.show_anim];
    _show_anim.text =@"1";
    [_show_anim setFont:[UIFont systemFontOfSize:100]];
    [_show_anim setTextColor:[UIColor blackColor]];
    
    
    
    
    
    [NSTimer scheduledTimerWithTimeInterval:1.0
                                     target:self
                                   selector:@selector(zeronumber)
                                   userInfo:nil
                                    repeats:NO];
}

-(void)twonumber
{
    self.show_anim.hidden=NO;
    [take_picker.view addSubview:self.show_anim];
    [take_picker.view bringSubviewToFront:self.show_anim];
    _show_anim.text =@"2";
    [_show_anim setFont:[UIFont systemFontOfSize:100]];
    [_show_anim setTextColor:[UIColor blackColor]];
    
    
    
    [NSTimer scheduledTimerWithTimeInterval:1.0
                                     target:self
                                   selector:@selector(onenumber)
                                   userInfo:nil
                                    repeats:NO];
}
-(void)threenumber

{
    self.show_anim.hidden=NO;
    [take_picker.view addSubview:self.show_anim];
    [take_picker.view bringSubviewToFront:self.show_anim];
    [_show_anim setTextColor:[UIColor blackColor]];
    
    
    
    [_show_anim setFont:[UIFont systemFontOfSize:100]];
    _show_anim.text =@"3";
    
    
    [NSTimer scheduledTimerWithTimeInterval:1.0
                                     target:self
                                   selector:@selector(twonumber)
                                   userInfo:nil
                                    repeats:NO];
}

- (void) rapidEarsDidReceiveLiveSpeechHypothesis:(NSString *)hypothesis recognitionScore:(NSString *)recognitionScore
{
    NSLog(@"rapidEarsDidReceiveLiveSpeechHypothesis: %@",hypothesis);
    NSLog(@"The received hypothesis is %@ with a score of %@ and an ID of ", hypothesis, recognitionScore); // Log it.
    
    
    
    
    
    double recogScore = -1 * ([recognitionScore doubleValue]);
    
    
    if (recogScore > 500)
    {
        //snap detected
        // display the hypothesis in the you said: box
        
        
        NSString *strTold = [NSString stringWithFormat:@"\"%@\"", hypothesis];
        
        NSLog(@"Valid: %@",strTold);
        
        NSInteger slidervalue = [[GLOBAL getGlobalValueFor:SLIDER_VALUE]integerValue];
        
        
        if (slidervalue ==1)
        {
            [self stopButtonAction];
            //[_a6 play];
            NSLog(@"time delay is 1");
            [self onenumber];
            
        }
        else if (slidervalue==2)
        {
            [self stopButtonAction];
            //[_a6 play];
            NSLog(@"time delay is 2");
            [self twonumber];
            
        }
        else if (slidervalue==3)
        {
            [self stopButtonAction];
            //[_a6 play];
            NSLog(@"time delay is 3");
            [self threenumber];
            
            
        }
        else
        {
            
            //[_a6 play];
            NSLog(@"pic taken");
            [take_picker takePicture];
            
        }
    }
    else
    {
        
        // display the hypothesis in the you said: box
        NSString *strTold = [NSString stringWithFormat:@"\"%@\"", hypothesis];
        NSLog(@"InValid: %@",strTold);
    }
}

- (void) rapidEarsDidReceiveFinishedSpeechHypothesis:(NSString *)hypothesis recognitionScore:(NSString *)recognitionScore
{
    NSLog(@"rapidEarsDidReceiveFinishedSpeechHypothesis: %@",hypothesis);
    //[[OEPocketsphinxController sharedInstance] stopListening];
}

- (void) pocketsphinxFailedNoMicPermissions
{
    NSLog(@"The user has never set mic permissions or denied permission to this app's mic, so listening will not start.");
    self.startupFailedDueToLackOfPermissions = TRUE;
}

- (void) micPermissionCheckCompleted:(BOOL)result
{
    if(result == TRUE)
    {
        self.restartAttemptsDueToPermissionRequests++;
        if(self.restartAttemptsDueToPermissionRequests == 1 && self.startupFailedDueToLackOfPermissions == TRUE)
        { // If we get here because there was an attempt to start which failed due to lack of permissions, and now permissions have been requested and they returned true, we restart exactly once with the new permissions.
            [self startListening]; // Only do this once.
            self.startupFailedDueToLackOfPermissions = FALSE;
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Lanocast" message:@"Please enable mic settings" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] ;
        [alert show];
    }
}

#pragma mark - Button Actions

- (IBAction) suspendListeningButtonAction
{
    [[OEPocketsphinxController sharedInstance] suspendRecognition];
    (self.waveformView.alpha=0);
}

- (IBAction) resumeListeningButtonAction
{
    [[OEPocketsphinxController sharedInstance] resumeRecognition];
    (self.waveformView.alpha=1);
}

- (void)star_camara
{
    [AppDelegate shredDelegate].isSavedPhoto = NO;
    [self open_camara];
    [self startButtonAction];
    
    
}

- (IBAction) stopButtonAction
{
    [[OEPocketsphinxController sharedInstance] stopListening];
    //(self.waveformView.alpha=0);
}

- (IBAction) startButtonAction
{
    [self startListening];
    //(self.waveformView.alpha=1);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload
{
    [self setDisplay:nil];
    [self setDisplayHint:nil];
    [super viewDidUnload];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
    return YES;
}

- (BOOL)shouldAutorotate
{
    return YES;
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAll;
}

-(BOOL)prefersStatusBarHidden
{
    return NO;
}

-(IBAction)on_off:(id)sender
{
    dispatch_async(dispatch_get_main_queue(), ^
                   {
                       if ([myswitch isOn])
                       {
                           NSLog(@"on");
                           //[self.voiceRecognition startVoiceRecognition];
                           
                           [self startButtonAction];
                           (self.waveformView.alpha=1);
                       }
                       else
                       {
                           NSLog(@"off");
                           //[self.voiceRecognition stopVoiceRecognition];
                           
                           [self stopButtonAction];
                           (self.waveformView.alpha=0);
                       }
                   });
}





//-(void)takeFinalCameraPic
//{
//    dispatch_async(dispatch_get_main_queue(), ^
//    {
//        cameraView = [[VksCameraView alloc]initWithFrame:self.view.frame];
//        [cameraView setDelegate:(NSObject<VksCameraViewDelegate> *)self];
//        [cameraView  performSelector:@selector(takePicture) withObject:nil afterDelay:1.0f];
//        //[cameraView takePicture];
//
//    });
//}
//-(void)wv
//{
//    [self performSegueWithIdentifier:@"ss1" sender:nil];
//}
//-(void)cameraView:(VksCameraView*)cameraView didFinishTakingPicture:(UIImage *)image withInfo:(NSDictionary*)info meta:(NSDictionary *)meta
//{
//    //if([[GLOBAL getGlobalValueFor:IS_SNAP_TAKEN_FIRST_TIME]isEqualToString:_NO])
//    //{
//
//
//        self.captureImage.image = image;
//
//
//
//        NSLog(@"Image taken and successfully received");
//        UILabel *myLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, self.view.frame.size.height-30, 250, 30)];
//
//        myLabel.autoresizingMask =UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleBottomMargin|UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleWidth;
//
//        [myLabel setTag:111];
//        myLabel.text = @"Photo Taken with Lanocast";
//        myLabel.textColor = [UIColor whiteColor];
//        myLabel.font=[UIFont fontWithName:@"AppleSDGothicNeo-Thick" size:15];
//
//
//
//
//    UIView *blackview1 = [[UIView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-130, self.view.frame.size.width, self.view.frame.size.height/6)];
//
//   blackview1.backgroundColor=[UIColor blackColor];
//
//    [blackview1 setAlpha:0.7];
//
//    [self.view addSubview:blackview1];
//
//    UIButton *fb =[[UIButton alloc]initWithFrame:CGRectMake(15,10 , 40, 45)];
//    UIImage *btnImage = [UIImage imageNamed:@"i5.png"];
//    [fb setImage:btnImage forState:UIControlStateNormal];
//
//    [blackview1 addSubview:fb];
//
//
//
//    UIButton *instagrm =[[UIButton alloc]initWithFrame:CGRectMake(100,10 , 40, 45)];
//    UIImage *btnImage2 = [UIImage imageNamed:@"i5.png"];
//    [instagrm setImage:btnImage2 forState:UIControlStateNormal];
//
//    [blackview1 addSubview:instagrm];
//
//
//    UIButton *third =[[UIButton alloc]initWithFrame:CGRectMake(self.view.frame.size.width-40,10 , 40, 45)];
//
//    UIImage *btnImage3 = [UIImage imageNamed:@"i5.png"];
//    [third setImage:btnImage3 forState:UIControlStateNormal];
//
//    [blackview1 addSubview:third];
//
//    [third addTarget:self
//               action:@selector(wv)
//     forControlEvents:UIControlEventTouchUpInside];
//
//
//
//
//
//
//    UIView *blackview = [[UIView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-65, self.view.frame.size.width, self.view.frame.size.height/6)];
//
//    blackview.backgroundColor=[UIColor blackColor];
//    [self.view addSubview:blackview];
//
//    UIButton *retake =[[UIButton alloc]initWithFrame:CGRectMake(15,20 , 59, 20)];
//
//    [retake setTitle:@"Retake" forState:UIControlStateNormal];
//    [retake setTintColor:[UIColor redColor]];
//    [blackview addSubview:retake];
//
//    [retake addTarget:self
//               action:@selector(initializeCamera)
//     forControlEvents:UIControlEventTouchUpInside];
//
//
//
//
//
//
//    UIButton *usepic =[[UIButton alloc]initWithFrame:CGRectMake(self.view.frame.size.width-115,20,115,20)];
//
//    [usepic setTitle:@"Save Photo" forState:UIControlStateNormal];
//
//    [usepic setTintColor:[UIColor redColor]];
//
//    [blackview addSubview:usepic];
//
//
//    [usepic addTarget:self
//               action:@selector(createImage1:)
//     forControlEvents:UIControlEventTouchUpInside];
//
//
//
//        for (UIView *object in captureImage.subviews)
//        {
//            if ([object isKindOfClass:[UILabel class]])
//            {
//                if(object.tag == 111)
//                {
//                    [object removeFromSuperview];
//                }
//            }
//        }
//
//        [captureImage addSubview:myLabel];
//
//        UIImage *lastCapturedImage = [self createImage:captureImage];
//
//        NSData* imageData =UIImageJPEGRepresentation(lastCapturedImage,0.1);
//
//
//        //NSData* myEncodedImageData = [NSKeyedArchiver archivedDataWithRootObject:imageData];
//
//
//        [[NSUserDefaults standardUserDefaults]setObject:imageData forKey:LAST_IMAGE];
//        [[NSUserDefaults standardUserDefaults]synchronize];
//    }
//        //else
//    //{
//        //[GLOBAL setGlobalValue:_NO For:IS_SNAP_TAKEN_FIRST_TIME];
//    //}
////}
//
//-(void)cameraView:(VksCameraView *)cameraView didErrorOnTakePicture:(NSError *)error
//{
//    //NSString *strErrorDesc = [error description];
//    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enable Camera from settings" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
//    [alert show];
//}
//
//-(void)cameraView:(VksCameraView*)cameraView didCreateCaptureConnection:(AVCaptureConnection*)captureConnection
//{
//
//}
//
- (void)dealloc
{
    openEarsEventsObserver.delegate = nil;
}

//-(UIImage *)createImage:(UIImageView *)imgView
//{
//    UIGraphicsBeginImageContextWithOptions(imgView.bounds.size, NO,0);
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    [imgView.layer renderInContext:context];
//    UIImage *imgs = UIGraphicsGetImageFromCurrentImageContext();
//    UIGraphicsEndImageContext();
//    UIImageWriteToSavedPhotosAlbum(imgs, nil, nil, nil);/////uncomment  to start photo saving
//    return imgs;
//}


- (IBAction)again_take_pic:(id)sender
{
    /* take_picker = [[UIImagePickerController alloc] init];
     take_picker.delegate = self;
     take_picker.allowsEditing = YES;
     take_picker.sourceType = UIImagePickerControllerSourceTypeCamera;
     take_picker.cameraDevice=UIImagePickerControllerCameraDeviceFront;*/
    [self startListening]; // Only do this once.
    
    [self presentViewController:take_picker animated:YES completion:NULL];
}

-(void)Close_click {
    
    [take_picker dismissViewControllerAnimated:YES completion:nil];
    [self removeCancelButton];
    [[OEPocketsphinxController sharedInstance] stopListening];
    [AppDelegate shredDelegate].isFromCancel = YES;
    self.btnRetake.hidden = FALSE;
}

- (IBAction)Retake_click:(id)sender {
    [self star_camara];
}

-(void)removeCancelButton {
    [btnCameraClose removeFromSuperview];
}
@end
