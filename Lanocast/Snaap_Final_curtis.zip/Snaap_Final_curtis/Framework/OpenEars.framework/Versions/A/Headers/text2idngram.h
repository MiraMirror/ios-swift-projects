int text2idngram_main(int argc, char *argv[]);
