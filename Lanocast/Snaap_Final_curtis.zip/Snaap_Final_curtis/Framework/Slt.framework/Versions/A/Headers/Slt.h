//
//  Slt.h
//  Slt
//
//  Created by Halle on 8/7/12.
//  Copyright (c) 2012 Politepix. All rights reserved.
//

#import <OpenEars/OEFliteVoice.h>

@interface Slt : OEFliteVoice

@end
