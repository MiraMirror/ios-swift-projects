//
//  Settingview.h
//  Snaap
//
//  Created by pratikjain on 27/01/15.
//  Copyright (c) 2015 pratik jain. All rights reserved.
//

#import <UIKit/UIKit.h>

//global
#import "Global.h"
#define GLOBAL [Global sharedInstance]


#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MFMessageComposeViewController.h>


#import "DMActivityInstagram.h"

@interface Settingview : UIViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate,MFMailComposeViewControllerDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tvo;

@property(nonatomic, readonly, retain) NSString *localizedModel;

@property(nonatomic, strong)     UIDocumentInteractionController* docController;
@end
